This level is completed when you see the “you have correctly got the variable to the right value” message.
