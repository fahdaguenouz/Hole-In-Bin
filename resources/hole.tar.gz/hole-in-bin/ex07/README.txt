This level is completed when you see the “you have modified the target” message.
