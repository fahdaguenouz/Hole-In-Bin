This level is completed when you see the “you have changed the 'modified' variable” message.
