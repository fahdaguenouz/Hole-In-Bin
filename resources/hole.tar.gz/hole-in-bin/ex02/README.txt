This level is completed when you see the “you have correctly modified the variable” message.
