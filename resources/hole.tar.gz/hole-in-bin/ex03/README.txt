This level is completed when you see the “code flow successfully changed” message.
