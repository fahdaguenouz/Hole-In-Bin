This level is completed when you see the “that wasn't too bad now, was it?” message.
