This level is completed when you see the “level passed” message.
