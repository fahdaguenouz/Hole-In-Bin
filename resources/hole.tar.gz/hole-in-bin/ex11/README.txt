This level is completed when you see the “and we have a winner” message.
