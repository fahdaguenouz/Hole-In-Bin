This level is completed when you see the “code execution redirected!” message.
