This level is completed when you see the “you have hit the target correctly” message.
